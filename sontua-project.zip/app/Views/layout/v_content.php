<?php

if ($isi) {

    echo view($isi);
}
