<?php
echo view('layout/v_head.php');
echo view('layout/v_nav.php');
echo view('layout/v_content.php');
echo view('layout/v_footer.php');
