<?php

namespace Wildanfuady\WFcart;

class WFcart
{


    public static function totals($id_pembeli)
    {
        $session = session('cart' . $id_pembeli);
        return is_array($session) ? array_values($session) : array();
    }

    public function add_cart($id = null, $item = null, $id_pembeli)
    {
        if (session()->has('cart' . $id_pembeli)) { // sudah ada session cart
            $index = $this->exists($id,  $id_pembeli);
            $cart = array_values(session('cart'  . $id_pembeli));
            if ($index == -1) {
                array_push($cart, $item);
            } else {
                $cart[$index]['quantity']++;
            }
            return session()->set('cart'  . $id_pembeli, $cart);
        } else { // belum ada session cart
            $cart = array($item);
            return session()->set('cart'  . $id_pembeli, $cart);
        }
    }

    public function exists($id = null, $id_pembeli)
    {
        $items = array_values(session('cart'  . $id_pembeli));
        for ($i = 0; $i < count($items); $i++) {
            if ($items[$i]['id'] == $id) {
                return $i;
            }
        }
        return -1;
    }

    public function update($id, $jumlah, $id_pembeli)
    {
        $index = $this->exists($id,  $id_pembeli);
        $cart = array_values(session('cart'  . $id_pembeli));
        $cart[$index]['quantity'] = $jumlah;
        return session()->set('cart'  . $id_pembeli, $cart);
    }

    public function remove($id = null, $id_pembeli)
    {
        $index = $this->exists($id, $id_pembeli);
        $cart = array_values(session('cart' . $id_pembeli));
        $product = $cart[$index]['name'];
        unset($cart[$index]);
        return session()->set('cart'  . $id_pembeli, $cart);
    }

    public static function count_totals($id_pembeli)
    {
        $total = 0;
        $session = session('cart'  . $id_pembeli);
        $items = is_array($session) ? array_values($session) : array();
        foreach ($items as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        return $total;
    }
}
